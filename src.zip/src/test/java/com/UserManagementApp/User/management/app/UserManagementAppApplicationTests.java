package com.UserManagementApp.User.management.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
